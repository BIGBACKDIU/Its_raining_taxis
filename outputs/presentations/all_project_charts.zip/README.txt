All 44 unique saved project graphs appear in all/ (multipart charts use several files).
selected/ contains the eleven main-story chart exports. No models were re-estimated.
Fonts and their OFL licences are included for editing the accompanying PowerPoint.
